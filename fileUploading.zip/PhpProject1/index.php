<?php
define('DSN', 'mysql:host=localhost;dbname=nav_footer');
define('USERNAME', 'root');
define('PASSWORD', '');

try{
    $DB = new PDO(DSN,USERNAME, PASSWORD);
    
} catch (Exception $e) {
    echo $e->getMessage();
}

try{
    $sql = "SELECT *FROM navigation";
    $result = $DB->query($sql);
    $row_count = $result->rowCount();
    if($row_count){
        $rows = $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    
} catch (Exception $e) {
    echo $e->getMeassage;
}

$items = $rows; 

?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="navigation1.css"/>
    </head>
   <body>
   <header>
       <?php
$items = $rows;
$id = '';

echo "<ul class='multidrop'>";
foreach($items as $item){
    if($item['parent_id']==0){
        $link = $item['link'];
        echo "<li><a href=$link>".$item['name']."</a>";
        $id = $item['id'];
        sub($items,$id);
        echo "</li>";
    }
    
}
echo "</ul>";


function sub($items, $id){
echo "<ul>";
    foreach ($items as $item){
        if($item['parent_id']== $id){
            echo "<li><a href='#'>".$item['name']."</a>";
            //sub($items, $item['id']);
            echo "</li>";
        }
    
    }
    echo "</ul>"; 
}
   

?>   
   </header>




        <?php include 'db.php'; ?>
        <h1>Courses</h1>
        <?php
        
        
        
        
        $sql_001 = "SELECT * FROM courses";
        $result_001 = $conn->query($sql_001);


        if ($result_001->num_rows > 0) {


            echo "<ul>";
            while ($row = $result_001->fetch_assoc()) {
                $code = $row['code'];
                $name = $row['name'];
                $idcourses = $row['idcourses'];
                echo "<li><a href='viewModules.php?id=$idcourses'>$code :  $name </a></li>";
            }
            echo "</ul>";
        }
         mysqli_close($conn);
        ?>



        

    </body>
</html>
