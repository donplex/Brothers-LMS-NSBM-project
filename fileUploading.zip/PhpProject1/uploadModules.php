<!DOCTYPE html>

<html>
    <head>
        <title>NSBM | LMS </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="upload_Styles.css">
    </head>
    <body>
        <?php include 'db.php'; ?>
        <h1>Upload Your Module</h1>
        <?php
        $sql_001 = "SELECT * FROM courses";
        $result_001 = $conn->query($sql_001);
        ?>

        <div class="form">
        <form method="post" action="create_modules.php" enctype="multipart/form-data">

            <div class="btn">
            <input type="file" name="upload_file">
            </div>
            <br>
            
            <input type="text" name="name" placeholder="name">
            <select name="course">

                <?php
                if ($result_001->num_rows > 0) {
                    while ($row = $result_001->fetch_assoc()) {
                        $name = $row['name'];
                        echo "<option>$name</option>";
                    }
                }
                ?>
            </select>
            <input type="submit">
        </form>
        </div>    
    </body>
</html>
