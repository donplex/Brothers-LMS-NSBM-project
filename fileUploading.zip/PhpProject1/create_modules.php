<?php

include 'db.php';
$name = $_POST["name"];
$course = $_POST["course"];

$target_dir = "uploads/notes/";
$target_file = $target_dir . basename($_FILES["upload_file"]["name"]);
$target_type = $_FILES["upload_file"]["type"];


// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
}
if (move_uploaded_file($_FILES["upload_file"]["tmp_name"], $target_file)) {
    echo "The file " . basename($_FILES["upload_file"]["name"]) . " has been uploaded.";

    $sql_000 = "SELECT idcourses FROM courses WHERE name='$course'";
    $result_000 = $conn->query($sql_000);
    $row = $result_000->fetch_assoc();
    $idcourses = $row['idcourses'];


    $sql_001 = "INSERT INTO modules (name,path,type,courses_idcourses) "
            . "VALUES ('$name','$target_file','$target_type','$idcourses')";

    if (mysqli_query($conn, $sql_001)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql_001 . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
} else {
    echo "Sorry, there was an error uploading your file.";
}
    
   





