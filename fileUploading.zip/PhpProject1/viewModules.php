<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php include 'db.php'; ?>
        <h1>Modules</h1>
        <?php
        
        
        
        $courses_idcourses = $_GET['id'];
        $sql_001 = "SELECT * FROM modules WHERE courses_idcourses='$courses_idcourses'";
        $result_001 = $conn->query($sql_001);


        if ($result_001->num_rows > 0) {


            echo "<ul>";
            while ($row = $result_001->fetch_assoc()) {
                $name = $row['name'];
                $path = $row['path'];
                echo "<li><a href='$path'>$name</a></li>";
            }
            echo "</ul>";
        }
         mysqli_close($conn);
        ?>



        

    </body>
</html>
