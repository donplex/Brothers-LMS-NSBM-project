<?php 
	
	
	$servername = "localhost";	
	$username = "root";	
	$password = "";	 //pasword required.
	$dbname = "optimaz";

	// Create connection
	$conn = new mysqli($servername, $username,$password,$dbname);
	
	
		
?>